#! /bin/bash
# Copies updated files from picdok source directory to the directory
# where the distribution version is kept.

# WARNING this is experimental. 

DEST_DIR=picdok-0-2

cp -puv ./src/*.cpp ../$DEST_DIR/src/
cp -puv ./hdr/*.h ../$DEST_DIR/hdr/
cp -puv ./frm/*.ui ../$DEST_DIR/frm/
cp -puv ./html/* ../$DEST_DIR/html/
cp -puv ./misc/* ../$DEST_DIR/misc/
cp -puv picdok.pro ../$DEST_DIR/
cp -puv README ../$DEST_DIR/
cp -puv picdok.qrc ../$DEST_DIR/
