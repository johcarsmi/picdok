#! /bin/bash
# Copies updated files from picdok source directory to the directory
# where the distribution version is kept.

# WARNING this is experimental and at present will stop the distribution
# working as the file locations do not match!

DEST_DIR=picdok-0-2
find . -maxdepth 1 -type f ! -name '*.pro*' \
-exec cp -puv '{}' ../$DEST_DIR/source/ \;
cp -puv picdok.pro ../$DEST_DIR/
